<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

// 📸 Provera da li je fajl poslat
if (!isset($_FILES['texture']) || $_FILES['texture']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(["success" => false, "message" => "Greška pri uploadu slike."]);
    exit;
}

// 📋 Uzimamo ime tkanine iz POST-a
$name = $_POST['name'] ?? 'Bez naziva';

// 📁 Putanja gde čuvamo slike
$uploadDir = '../uploads/fabrics/';

// Ako folder ne postoji — kreiraj ga
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// 📄 Napravi jedinstveno ime fajla
$filename = time() . '_' . basename($_FILES['texture']['name']);
$targetPath = $uploadDir . $filename;

// 🔧 Pomeri fajl iz privremene u upload fasciklu
if (move_uploaded_file($_FILES['texture']['tmp_name'], $targetPath)) {

    // Relativna putanja za bazu
    $texturePath = '/custom-suits-backend/uploads/fabrics/' . $filename;

    // 📊 Prosečna svetlina slike (0 - crno, 1 - belo)
    $cmd = "magick convert " . escapeshellarg($targetPath) . " -colorspace Gray -format \"%[fx:mean]\" info:";
    $brightness = (float)shell_exec($cmd);

    // 🧠 Klasifikacija tona
    if ($brightness < 0.28) {
        $tone = "dark";
    } elseif ($brightness < 0.55) {
        $tone = "medium";
    } else {
        $tone = "light";
    }

    // 🧾 Upis u bazu
    $stmt = $pdo->prepare("INSERT INTO fabrics (name, texture_path, tone) VALUES (?, ?, ?)");
    $stmt->execute([$name, $texturePath, $tone]);

    echo json_encode([
        "success" => true,
        "message" => "Tkanina uspešno dodata!",
        "tone"=> $tone,
        "brightness"=> $brightness,
        "texture"=> $texturePath
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo json_encode(["success" => false, "message" => "Neuspešno premeštanje fajla."]);
}
