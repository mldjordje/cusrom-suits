<?php
// ✅ CORS — omogući i lokalni dev i produkciju
$allowed_origins = [
    'https://custom-suits.vercel.app',
    'https://customsuits.adspire.rs',
    'https://www.customsuits.adspire.rs',
    'http://localhost:3000', // ✅ dodato za lokalni razvoj
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin && in_array($origin, $allowed_origins, true)) {
    header("Access-Control-Allow-Origin: $origin");
}

header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header('Content-Type: application/json; charset=utf-8');

// ✅ Preflight OPTIONS zahtev
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// 🔗 Konekcija na bazu
require_once '../config/database.php';

try {
    $stmt = $pdo->query("
        SELECT 
            id, 
            name, 
            CONCAT('https://customsuits.adspire.rs/uploads/fabrics/', SUBSTRING_INDEX(texture_path, '/', -1)) AS texture, 
            tone, 
            created_at 
        FROM fabrics 
        ORDER BY id DESC
    ");

    $fabrics = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $fabrics
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
