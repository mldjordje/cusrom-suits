<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
set_time_limit(900);

$key = 'santos_cron_7Kp92vLmQ4xR8nT6bZcW3yFaDqE1uH5s';

if (($_GET['key'] ?? '') !== $key) {
    http_response_code(403);
    die('Forbidden');
}

$job = $_GET['job'] ?? '';

$files = [
    'moffice' => '/home/agyc3416/santos-cron/moffice-sync.php',
    'ananas' => '/home/agyc3416/santos-cron/ananas-sync.php',
];

echo '<pre>';

if (!isset($files[$job])) {
    echo "Use:\n";
    echo "https://santos.rs/run-sync.php?key={$key}&job=moffice\n";
    echo "https://santos.rs/run-sync.php?key={$key}&job=ananas\n";
    echo '</pre>';
    exit;
}

$file = $files[$job];

echo "Running {$job}\n";
echo "File: {$file}\n";

if (!file_exists($file)) {
    echo "ERROR: File does not exist\n";
    echo '</pre>';
    exit;
}

if (!is_readable($file)) {
    echo "ERROR: File is not readable\n";
    echo '</pre>';
    exit;
}

echo "START\n\n";
include $file;
echo "\n\nEND\n";
echo '</pre>';