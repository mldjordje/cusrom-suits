<?php

$dbname = "agyc3416_santos_sa2025";
$servername = "mysql";
$user = "agyc3416_user2025";
$password = 'HcDIH(k*VtbI';

if(mysqli_connect($servername,$user,$password) == false)
{
    echo "GRESKA ==>>". mysqli_error();
}
else
{
    $conn = mysqli_connect($servername,$user,$password);
}
if(mysqli_select_db($conn, $dbname) == false)
{
    echo "GRESKA 2 ==>>".mysqli_error();
}
else
{
    $db = mysqli_select_db($conn, $dbname);
}
mysqli_query($conn, "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
mysqli_query($conn,"SET sql_mode=''");
//------------------------------------------------------------
$sortprod = " ORDER BY sort_number, name, productid";
$sortcat = " ORDER BY sort_number, name, categoryprid";

?>